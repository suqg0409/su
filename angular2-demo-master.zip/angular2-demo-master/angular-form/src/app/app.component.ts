import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<hero-form>Loading...</hero-form>',
})
export class AppComponent  { name = 'Angular'; }
