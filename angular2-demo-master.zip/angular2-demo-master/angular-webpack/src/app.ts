import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'my-app',
    templateUrl: 'name.component.html'
})
export class AppComponent  implements OnInit {
    constructor() { }

    ngOnInit() { }
    
}