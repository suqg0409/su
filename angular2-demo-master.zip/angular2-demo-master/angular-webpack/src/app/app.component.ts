import {Component} from '@angular/core';
import '../../public/css/styles.css';

@Component({
    modelId:model.id,
    selector:"my-app",
    templateUrl:'./app.component.html',
    styleUrls:['./app.component.css']
})
export class AppComponent{

}