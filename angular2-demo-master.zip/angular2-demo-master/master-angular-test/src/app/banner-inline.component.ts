import {Component} from '@angular/core';

@Component({
  moduleId:module.id,
  selector:'app-banner',
  templateUrl:'./banner.component.html'
})
export class BannerComponent{
  title = "test tour of heroes";
}
