# angular2-demo
angular2-demo from https://angular.io

every directory is an isolate angular2 project

and each project is an copy from https://github.com/angular/quickstart

##How to run

```
cd $targetProject
npm install
npm start
```
