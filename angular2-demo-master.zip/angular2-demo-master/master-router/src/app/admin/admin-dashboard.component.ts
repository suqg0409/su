import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    template:`<p>Dashboard</p>`
})
export class AdminDashboardComponent implements OnInit {
    constructor() { }

    ngOnInit() { }

}