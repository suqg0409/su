import {Component, OnInit} from '@angular/core';

@Component({
	moduleId:module.id,
	template:`<p>英雄管理</p>`
})
export class ManageHeroesComponent implements OnInit{
	constructor(){

	}
	ngOnInit(){

	}
}