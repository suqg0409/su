import {Component, OnInit} from '@angular/core';

@Component({
	moduleId:module.id,
	template:`<p>危机管理</p>`
})
export class ManageCrisesComponent implements OnInit{
	constructor(){

	}
	ngOnInit(){

	}
}