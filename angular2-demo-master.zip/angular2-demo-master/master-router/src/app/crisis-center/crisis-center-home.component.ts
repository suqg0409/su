import {Component, OnInit} from '@angular/core';

@Component({
    moduleId:module.id,
    template:`<p>欢迎进入危机中心</p>`
})

export class CrisisCenterHomeComponent implements OnInit{

    constructor(){

    }
    ngOnInit(){

    }
}