import { Hero } from './hero';


export var HEROES: Hero[] = [
    { id: 1, name: "allen", isSecret: false },
    { id: 2, name: "bob", isSecret: true },
    { id: 3, name: "curry", isSecret: false }
]