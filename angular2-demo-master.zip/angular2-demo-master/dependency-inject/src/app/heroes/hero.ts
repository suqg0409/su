export class Hero{
    id:number;
    name:string;
    isSecret :boolean = false;
}